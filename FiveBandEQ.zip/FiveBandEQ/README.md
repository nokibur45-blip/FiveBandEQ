# Five Band EQ (Android)

A WebView app that bundles the EQ page from `app/src/main/assets/index.html`.

## Build the APK without Android Studio (GitHub)

1. Create a free account at github.com and make a new repository.
2. Click "uploading an existing file" and drag in everything from this folder,
   including the hidden `.github` folder. Commit.
3. Open the Actions tab, pick "Build APK", wait about 3 minutes for the green tick.
4. Open that run, download `FiveBandEQ-apk` from Artifacts, unzip it and you have `app-debug.apk`.

## Build the APK with Android Studio

**Android Studio (easiest)**
1. File > Open, choose this folder, wait for Gradle sync.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. The file is at `app/build/outputs/apk/debug/app-debug.apk`.

**Command line** (needs JDK 17 and the Android SDK, with `ANDROID_HOME` set)

    gradle assembleDebug   (Gradle 8.7 or newer)

## Install

Copy `app-debug.apk` to your phone and open it. Android will ask you to allow
installs from that source the first time.

## Notes

- Needs Android 10 (API 29) or newer.
- The Barlow Condensed font loads from Google Fonts when online. Offline, the
  app falls back to the phone's condensed system font.
- "My audio" opens the phone's file picker. Demo loop needs no files.
- This is a debug-signed build, fine for your own phone. For the Play Store you
  need a release build signed with your own key.
